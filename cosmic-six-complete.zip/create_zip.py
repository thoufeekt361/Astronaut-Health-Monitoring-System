import os
import zipfile
from pathlib import Path

root_dir = Path(r"C:\Users\Thoufeek\.gemini\antigravity\scratch\cosmic-six")
zip_path = root_dir / "cosmic-six-complete.zip"

excluded_dirs = {"node_modules", "dist", ".git", "__pycache__", ".vscode", ".idea"}
excluded_files = {"cosmic-six-complete.zip"}

print(f"Creating ZIP archive at: {zip_path}")
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
    for foldername, subfolders, filenames in os.walk(root_dir):
        # Prune unwanted directories
        subfolders[:] = [d for d in subfolders if d not in excluded_dirs]
        for filename in filenames:
            if filename in excluded_files:
                continue
            filepath = Path(foldername) / filename
            arcname = filepath.relative_to(root_dir)
            zipf.write(filepath, arcname)

size_mb = os.path.getsize(zip_path) / (1024 * 1024)
print(f"Archive successfully generated: {zip_path} ({size_mb:.2f} MB)")
